# Corpus rights

The writing corpus in this local project remains the intellectual property of its author.
It is included solely as private training material for this project. No license to publish,
redistribute, scrape, or use the corpus to train other models is granted by this repository.

The `.gitignore` excludes corpus files and model weights by default. Review this before making
any GitHub repository public.
