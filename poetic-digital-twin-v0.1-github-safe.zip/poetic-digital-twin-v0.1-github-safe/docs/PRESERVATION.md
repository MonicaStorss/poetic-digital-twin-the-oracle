# Preservation strategy

Poetic Twin v0.1 is designed to survive ordinary package and hosting changes.

1. The original corpus is preserved byte-for-byte and identified by SHA-256.
2. The processed corpus records the single transformation used for v0.1.
3. The GPT-2 base model and tokenizer are downloaded once into `models/base/gpt2`.
4. Training reads the base model with `local_files_only=True`.
5. The final fine-tuned model and tokenizer are saved into `models/poetic-twin-v0.1`.
6. Python and top-level library versions are pinned.
7. `src/archive_runtime.py` captures the exact installed package set and hashes all preserved artifacts after a successful run.
8. A Dockerfile can encapsulate the finished inference runtime.

For strongest preservation after the model works:

```bash
python src/archive_runtime.py
docker build -t poetic-twin:v0.1 .
docker save poetic-twin:v0.1 -o archive/poetic-twin-v0.1-docker.tar
```

Also make two offline copies of the entire project folder on separate storage media.
GitHub should be treated as a versioned code mirror, not the only archive and not the runtime dependency.
