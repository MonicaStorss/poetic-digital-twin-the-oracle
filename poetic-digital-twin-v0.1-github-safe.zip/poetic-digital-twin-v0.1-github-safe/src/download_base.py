#!/usr/bin/env python3
"""Download GPT-2 once, then save a complete local copy for offline use."""
from pathlib import Path
import argparse

from transformers import AutoModelForCausalLM, AutoTokenizer


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-id", default="openai-community/gpt2")
    parser.add_argument("--output", type=Path, default=Path("models/base/gpt2"))
    args = parser.parse_args()

    args.output.mkdir(parents=True, exist_ok=True)
    tokenizer = AutoTokenizer.from_pretrained(args.model_id)
    model = AutoModelForCausalLM.from_pretrained(args.model_id)
    tokenizer.save_pretrained(args.output)
    model.save_pretrained(args.output, safe_serialization=True)
    print(f"Saved base model and tokenizer to {args.output.resolve()}")
    print("After this succeeds, training and inference can use local_files_only=True.")


if __name__ == "__main__":
    main()
