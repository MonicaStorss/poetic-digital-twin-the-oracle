#!/usr/bin/env python3
"""Local-only co-writing server using Python's standard HTTP library."""
from __future__ import annotations
import argparse
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

MODEL = None
TOKENIZER = None
DEVICE = None
WEB_DIR = Path(__file__).resolve().parents[1] / "web"


def choose_device():
    if torch.cuda.is_available(): return torch.device("cuda")
    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available(): return torch.device("mps")
    return torch.device("cpu")


def generate(prompt, temperature, top_p, max_new_tokens, seed, num=3):
    torch.manual_seed(seed)
    inputs = TOKENIZER(prompt, return_tensors="pt").to(DEVICE)
    with torch.no_grad():
        rows = MODEL.generate(
            **inputs, do_sample=True, temperature=temperature, top_p=top_p,
            max_new_tokens=max_new_tokens, num_return_sequences=num,
            pad_token_id=TOKENIZER.eos_token_id, repetition_penalty=1.05,
        )
    prefix = inputs["input_ids"].shape[1]
    return [TOKENIZER.decode(r[prefix:], skip_special_tokens=True) for r in rows]


class Handler(BaseHTTPRequestHandler):
    def _send(self, code, body, content_type="application/json; charset=utf-8"):
        data = body if isinstance(body, bytes) else body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers(); self.wfile.write(data)

    def do_GET(self):
        if self.path in ("/", "/index.html"):
            self._send(200, (WEB_DIR / "index.html").read_bytes(), "text/html; charset=utf-8")
        else:
            self._send(404, json.dumps({"error":"not found"}))

    def do_POST(self):
        if self.path != "/generate":
            return self._send(404, json.dumps({"error":"not found"}))
        try:
            n = int(self.headers.get("Content-Length", "0"))
            payload = json.loads(self.rfile.read(n).decode("utf-8"))
            prompt = str(payload.get("prompt", ""))
            if not prompt.strip(): raise ValueError("Write something first.")
            result = generate(
                prompt=prompt,
                temperature=float(payload.get("temperature", 0.9)),
                top_p=float(payload.get("top_p", 0.92)),
                max_new_tokens=int(payload.get("max_new_tokens", 48)),
                seed=int(payload.get("seed", 42)),
                num=3,
            )
            self._send(200, json.dumps({"continuations": result}, ensure_ascii=False))
        except Exception as e:
            self._send(400, json.dumps({"error": str(e)}, ensure_ascii=False))

    def log_message(self, fmt, *args):
        print("[local]", fmt % args)


def main():
    global MODEL, TOKENIZER, DEVICE
    p=argparse.ArgumentParser()
    p.add_argument("--model", default="models/poetic-twin-v0.1")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=7860)
    a=p.parse_args()
    DEVICE=choose_device()
    TOKENIZER=AutoTokenizer.from_pretrained(a.model, local_files_only=True)
    if TOKENIZER.pad_token_id is None: TOKENIZER.pad_token=TOKENIZER.eos_token
    MODEL=AutoModelForCausalLM.from_pretrained(a.model, local_files_only=True).to(DEVICE).eval()
    print(f"Poetic Twin loaded on {DEVICE}. Open http://{a.host}:{a.port}")
    ThreadingHTTPServer((a.host,a.port), Handler).serve_forever()

if __name__ == "__main__": main()
