#!/usr/bin/env python3
from __future__ import annotations
import argparse
from pathlib import Path
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer


def device():
    if torch.cuda.is_available(): return torch.device("cuda")
    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available(): return torch.device("mps")
    return torch.device("cpu")


def main():
    p=argparse.ArgumentParser()
    p.add_argument("prompt")
    p.add_argument("--model", default="models/poetic-twin-v0.1")
    p.add_argument("--max-new-tokens", type=int, default=64)
    p.add_argument("--temperature", type=float, default=0.9)
    p.add_argument("--top-p", type=float, default=0.92)
    p.add_argument("--num", type=int, default=3)
    p.add_argument("--seed", type=int, default=42)
    a=p.parse_args()
    d=device(); torch.manual_seed(a.seed)
    tok=AutoTokenizer.from_pretrained(a.model, local_files_only=True)
    if tok.pad_token_id is None: tok.pad_token=tok.eos_token
    model=AutoModelForCausalLM.from_pretrained(a.model, local_files_only=True).to(d).eval()
    inputs=tok(a.prompt, return_tensors="pt").to(d)
    with torch.no_grad():
        out=model.generate(**inputs, do_sample=True, temperature=a.temperature, top_p=a.top_p,
                           max_new_tokens=a.max_new_tokens, num_return_sequences=a.num,
                           pad_token_id=tok.eos_token_id, repetition_penalty=1.05)
    n=inputs["input_ids"].shape[1]
    for i,row in enumerate(out,1):
        print(f"\n--- continuation {i} ---\n{tok.decode(row[n:], skip_special_tokens=True)}")

if __name__ == "__main__": main()
