#!/usr/bin/env python3
"""Record the exact successful runtime and file hashes for preservation."""
from __future__ import annotations
import hashlib, json, platform, subprocess, sys
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'archive'; OUT.mkdir(exist_ok=True)

def sha(path):
    h=hashlib.sha256();
    with path.open('rb') as f:
        for c in iter(lambda:f.read(1024*1024),b''): h.update(c)
    return h.hexdigest()

def main():
    freeze=subprocess.run([sys.executable,'-m','pip','freeze'],capture_output=True,text=True,check=True).stdout
    (OUT/'pip-freeze.txt').write_text(freeze,encoding='utf-8')
    paths=[]
    for rel in ['corpus/manifest.json','corpus/processed/mfa_thesis_body.txt','models/base/gpt2','models/poetic-twin-v0.1']:
        p=ROOT/rel
        if p.is_file(): paths.append({'path':rel,'sha256':sha(p)})
        elif p.is_dir():
            for f in sorted(x for x in p.rglob('*') if x.is_file()): paths.append({'path':str(f.relative_to(ROOT)),'sha256':sha(f)})
    record={'archived_utc':datetime.now(timezone.utc).isoformat(),'python':sys.version,'platform':platform.platform(),'files':paths}
    (OUT/'preservation-manifest.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    print('Wrote archive/pip-freeze.txt and archive/preservation-manifest.json')
if __name__=='__main__': main()
