#!/usr/bin/env python3
"""Prepare the MFA thesis for Poetic Twin v0.1 without normalizing poetic form.

The source file is NEVER modified. The only automatic edit is removal of the
front Table of Contents by starting the training text at the second occurrence
of the first work title ("The History of Breasts"). Line breaks, punctuation,
capitalization, spacing, markdown marks, and lexical choices in the body are
otherwise preserved exactly.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

FIRST_WORK = "The History of Breasts"


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, default=Path("corpus/source/mfa_thesis.md"))
    parser.add_argument("--output", type=Path, default=Path("corpus/processed/mfa_thesis_body.txt"))
    parser.add_argument("--manifest", type=Path, default=Path("corpus/manifest.json"))
    args = parser.parse_args()

    raw = args.source.read_bytes()
    text = raw.decode("utf-8")
    lines = text.splitlines(keepends=True)

    occurrences = [i for i, line in enumerate(lines) if line.strip() == FIRST_WORK]
    if len(occurrences) < 2:
        raise RuntimeError(
            f"Expected at least two exact occurrences of {FIRST_WORK!r}; found {len(occurrences)}. "
            "Refusing to guess where the manuscript body begins."
        )

    body_start = occurrences[1]
    body = "".join(lines[body_start:])
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(body, encoding="utf-8", newline="")

    body_bytes = body.encode("utf-8")
    manifest = {
        "corpus_id": "mfa-thesis-v0.1",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "source_path": str(args.source),
        "source_sha256": sha256_bytes(raw),
        "source_bytes": len(raw),
        "source_characters": len(text),
        "source_words_whitespace_count": len(text.split()),
        "source_lines": len(lines),
        "processing": {
            "body_start_rule": f"second exact occurrence of {FIRST_WORK!r}",
            "body_start_source_line_1_indexed": body_start + 1,
            "transformations_after_body_start": "none",
        },
        "processed_path": str(args.output),
        "processed_sha256": sha256_bytes(body_bytes),
        "processed_bytes": len(body_bytes),
        "processed_characters": len(body),
        "processed_words_whitespace_count": len(body.split()),
        "processed_lines": body.count("\n") + 1,
        "rights": "Corpus remains the author's work and is not licensed for redistribution by this project.",
    }
    args.manifest.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    print(json.dumps(manifest, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
