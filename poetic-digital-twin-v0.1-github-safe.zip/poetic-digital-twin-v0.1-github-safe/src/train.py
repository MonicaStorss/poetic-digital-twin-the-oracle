#!/usr/bin/env python3
"""Small, explicit GPT-2 full fine-tuning loop for a local poetry corpus.

This intentionally avoids Trainer, Datasets, PEFT, cloud logging, and hosted
services. The goal is a readable training loop with few dependencies.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import platform
import random
import sys
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path

import torch
from torch.optim import AdamW
from torch.utils.data import DataLoader, Dataset
import transformers
from transformers import AutoModelForCausalLM, AutoTokenizer


@dataclass
class Config:
    corpus: str
    base_model: str
    output: str
    block_size: int
    batch_size: int
    grad_accum: int
    epochs: int
    learning_rate: float
    weight_decay: float
    validation_fraction: float
    seed: int


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


class BlockDataset(Dataset):
    def __init__(self, blocks: list[torch.Tensor]):
        self.blocks = blocks
    def __len__(self):
        return len(self.blocks)
    def __getitem__(self, idx):
        x = self.blocks[idx]
        return {"input_ids": x, "attention_mask": torch.ones_like(x), "labels": x.clone()}


def select_device() -> torch.device:
    if torch.cuda.is_available():
        return torch.device("cuda")
    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


@torch.no_grad()
def evaluate(model, loader, device) -> float:
    model.eval()
    losses = []
    for batch in loader:
        batch = {k: v.to(device) for k, v in batch.items()}
        losses.append(float(model(**batch).loss.detach().cpu()))
    model.train()
    return sum(losses) / max(1, len(losses))


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--corpus", default="corpus/processed/mfa_thesis_body.txt")
    p.add_argument("--base-model", default="models/base/gpt2")
    p.add_argument("--output", default="models/poetic-twin-v0.1")
    p.add_argument("--block-size", type=int, default=256)
    p.add_argument("--batch-size", type=int, default=2)
    p.add_argument("--grad-accum", type=int, default=4)
    p.add_argument("--epochs", type=int, default=3)
    p.add_argument("--learning-rate", type=float, default=5e-5)
    p.add_argument("--weight-decay", type=float, default=0.01)
    p.add_argument("--validation-fraction", type=float, default=0.10)
    p.add_argument("--seed", type=int, default=1979)
    args = p.parse_args()
    cfg = Config(**vars(args))

    random.seed(cfg.seed)
    torch.manual_seed(cfg.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(cfg.seed)

    corpus_path = Path(cfg.corpus)
    base_path = Path(cfg.base_model)
    output_path = Path(cfg.output)
    if not corpus_path.exists():
        raise FileNotFoundError(f"Missing corpus: {corpus_path}. Run src/prepare_corpus.py first.")
    if not base_path.exists():
        raise FileNotFoundError(f"Missing local GPT-2 base model: {base_path}. Run src/download_base.py first.")

    device = select_device()
    print(f"Device: {device}")

    tokenizer = AutoTokenizer.from_pretrained(base_path, local_files_only=True)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    model = AutoModelForCausalLM.from_pretrained(base_path, local_files_only=True)
    model.config.pad_token_id = tokenizer.pad_token_id
    model.to(device)

    text = corpus_path.read_text(encoding="utf-8")
    token_ids = tokenizer(text, add_special_tokens=False, return_attention_mask=False)["input_ids"]
    # Insert EOS at the end of the manuscript, then cut into contiguous training blocks.
    token_ids.append(tokenizer.eos_token_id)
    block_size = min(cfg.block_size, model.config.n_positions)
    blocks = [
        torch.tensor(token_ids[i:i + block_size], dtype=torch.long)
        for i in range(0, len(token_ids) - block_size + 1, block_size)
    ]
    if len(blocks) < 4:
        raise RuntimeError(f"Corpus produced only {len(blocks)} full blocks; use a smaller --block-size.")

    # Deterministic block-level holdout. For v0.1 this is diagnostic, not a claim of
    # generalization across poems; future versions can use whole-work splits.
    indices = list(range(len(blocks)))
    random.Random(cfg.seed).shuffle(indices)
    n_val = max(1, round(len(indices) * cfg.validation_fraction))
    val_idx = set(indices[:n_val])
    train_blocks = [b for i, b in enumerate(blocks) if i not in val_idx]
    val_blocks = [b for i, b in enumerate(blocks) if i in val_idx]

    train_loader = DataLoader(BlockDataset(train_blocks), batch_size=cfg.batch_size, shuffle=True)
    val_loader = DataLoader(BlockDataset(val_blocks), batch_size=cfg.batch_size, shuffle=False)

    optimizer = AdamW(model.parameters(), lr=cfg.learning_rate, weight_decay=cfg.weight_decay)
    optimizer.zero_grad(set_to_none=True)
    global_step = 0
    history = []

    for epoch in range(1, cfg.epochs + 1):
        model.train()
        running = 0.0
        for step, batch in enumerate(train_loader, 1):
            batch = {k: v.to(device) for k, v in batch.items()}
            loss = model(**batch).loss / cfg.grad_accum
            loss.backward()
            running += float(loss.detach().cpu()) * cfg.grad_accum

            if step % cfg.grad_accum == 0 or step == len(train_loader):
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                optimizer.step()
                optimizer.zero_grad(set_to_none=True)
                global_step += 1

        train_loss = running / max(1, len(train_loader))
        val_loss = evaluate(model, val_loader, device)
        ppl = math.exp(min(val_loss, 20.0))
        history.append({"epoch": epoch, "train_loss": train_loss, "validation_loss": val_loss, "validation_perplexity": ppl})
        print(f"epoch={epoch} train_loss={train_loss:.4f} val_loss={val_loss:.4f} val_ppl={ppl:.2f}")

        checkpoint = output_path / f"checkpoint-epoch-{epoch}"
        checkpoint.mkdir(parents=True, exist_ok=True)
        model.save_pretrained(checkpoint, safe_serialization=True)
        tokenizer.save_pretrained(checkpoint)

    output_path.mkdir(parents=True, exist_ok=True)
    model.save_pretrained(output_path, safe_serialization=True)
    tokenizer.save_pretrained(output_path)

    metadata = {
        "model_name": "Poetic Twin v0.1",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "configuration": asdict(cfg),
        "corpus_sha256": sha256_file(corpus_path),
        "token_count": len(token_ids),
        "full_blocks": len(blocks),
        "train_blocks": len(train_blocks),
        "validation_blocks": len(val_blocks),
        "device_used": str(device),
        "python": sys.version,
        "platform": platform.platform(),
        "torch": torch.__version__,
        "transformers": transformers.__version__,
        "history": history,
        "note": "Full GPT-2 fine-tuning. Validation is block-level diagnostic for v0.1.",
    }
    (output_path / "poetic_twin_metadata.json").write_text(
        json.dumps(metadata, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    print(f"Saved final local model to {output_path.resolve()}")


if __name__ == "__main__":
    main()
