# Poetic Digital Twin v0.1

A local-first GPT-2 poetic co-writing instrument fine-tuned on one MFA thesis corpus.

## Design principles

- **Local-first:** corpus, base model, trained model, inference, and interface can all remain on one machine.
- **No RAG:** this is full causal-language-model fine-tuning, not retrieval over the poems.
- **Preserve form:** line breaks, punctuation, capitalization, spacing, and unusual forms are retained in the manuscript body.
- **Few moving parts:** core runtime is PyTorch + Transformers. The web interface uses Python's standard HTTP server, not a hosted UI service.
- **Versioned identity:** this build is `Poetic Twin v0.1`; later corpora should produce new model versions rather than silently replacing it.

## Corpus v0.1

The source file is `corpus/source/mfa_thesis.md`. It is ignored by Git by default.
Run:

```bash
python src/prepare_corpus.py
```

This removes only the front Table of Contents by beginning at the second exact occurrence of `The History of Breasts`. The manuscript body is otherwise copied without normalization. See `corpus/manifest.json` for hashes and counts.

## Install

Recommended: Python 3.11 in a dedicated environment.

```bash
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## 1. Download and preserve GPT-2 once

Internet is required for this step only:

```bash
python src/download_base.py
```

The official checkpoint ID used is `openai-community/gpt2`. After download, it is saved under `models/base/gpt2` and later scripts require local files.

## 2. Fine-tune

```bash
python src/train.py
```

Defaults are intentionally conservative for this small first corpus: GPT-2, 256-token blocks, batch size 2, gradient accumulation 4, three epochs, learning rate 5e-5. The script automatically uses CUDA, Apple MPS, or CPU.

CPU training is possible but can be slow. A GPU or Apple Silicon machine is preferable.

The final model is written to `models/poetic-twin-v0.1`, with an epoch-by-epoch checkpoint and a metadata file recording corpus hash, training arguments, package versions, losses, and device.

## 3. Test from the terminal

```bash
python src/generate.py "When the moon empties herself"
```

## 4. Open the local co-writing instrument

```bash
python src/server.py
```

Then visit `http://127.0.0.1:7860` in your browser. The browser offers three continuations. You may use one, edit it, or refuse all three. A session record can be saved as JSON.

Nothing is uploaded by the server. It binds to localhost by default.

## 5. Freeze the successful version

After training and testing:

```bash
python src/archive_runtime.py
```

Then follow `docs/PRESERVATION.md` to archive the Docker image as a file. This is the preservation step that protects the working artifact from future library changes.

## GitHub

Put the **code and documentation** on GitHub. Keep the private corpus, base weights, trained weights, and session logs local unless you intentionally choose otherwise. `.gitignore` is already configured for that separation.

## v0.1 limitation

The current corpus is small. The validation split is therefore block-level and diagnostic; it is not evidence that the model generalizes across unseen poems. The main v0.1 goal is to establish the complete preserved pipeline and inspect whether the model acquires a recognizable poetic inflection without excessive memorization.
