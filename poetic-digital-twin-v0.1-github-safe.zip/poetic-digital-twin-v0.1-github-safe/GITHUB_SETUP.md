# GitHub Setup — Poetic Digital Twin v0.1

This folder is safe to use as the initial GitHub repository. It intentionally excludes the private MFA thesis corpus and processed training text.

## Recommended repository

- Name: `poetic-digital-twin`
- Visibility: **Private** for the first build
- Do not add a GitHub-generated README, .gitignore, or license during repository creation; this folder already contains the project files.

## Easiest workflow: GitHub Desktop

1. Create a new empty private repository on GitHub named `poetic-digital-twin`.
2. Unzip this folder on your computer.
3. Add the unzipped folder as a local repository in GitHub Desktop.
4. Commit the existing files with a message such as `Initial Poetic Twin v0.1 scaffold`.
5. Publish/push to the private GitHub repository.

## Command-line workflow

From inside this folder:

```bash
git init
git add .
git commit -m "Initial Poetic Twin v0.1 scaffold"
git branch -M main
git remote add origin <YOUR_REPOSITORY_URL>
git push -u origin main
```

## Then restore the private corpus locally

Copy your thesis into:

`corpus/source/mfa_thesis.md`

It is ignored by Git. Run:

```bash
python src/prepare_corpus.py
```

Never use `git add -f` on the corpus, model weights, session records, or archive files unless you intentionally want to publish them.
